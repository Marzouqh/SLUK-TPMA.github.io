from flask import Flask, request, jsonify
from flask_cors import CORS
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity
import mysql.connector

app = Flask(__name__)
CORS(app)
app.config["JWT_SECRET_KEY"] = "your_secret_key"  # Change this for security
jwt = JWTManager(app)

# Database Connection
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="yourpassword",
    database="tpma"
)
cursor = db.cursor()

# User Login API
@app.route('/api/login', methods=['POST'])
def login():
    data = request.json
    reg_no = data.get("registration_number")
    password = data.get("password")

    cursor.execute("SELECT * FROM students WHERE registration_number=%s AND password=%s", (reg_no, password))
    user = cursor.fetchone()

    if user:
        access_token = create_access_token(identity=reg_no)
        return jsonify({"message": "Login successful", "token": access_token})
    else:
        return jsonify({"message": "Invalid credentials"}), 401

# Protected API (Requires Login)
@app.route('/api/protected', methods=['GET'])
@jwt_required()
def protected():
    current_user = get_jwt_identity()
    return jsonify({"message": "Access granted", "user": current_user})

if __name__ == '__main__':
    app.run(debug=True)
