import mysql.connector

# Connect to MySQL server (adjust credentials if needed)
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="yourpassword"
)

cursor = db.cursor()

# Create TPMA database
cursor.execute("CREATE DATABASE IF NOT EXISTS tpma")
cursor.execute("USE tpma")

# Create Students Table
cursor.execute("""
    CREATE TABLE IF NOT EXISTS students (
        id INT AUTO_INCREMENT PRIMARY KEY,
        registration_number VARCHAR(20) UNIQUE NOT NULL,
        name VARCHAR(100) NOT NULL,
        email VARCHAR(100) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        gender ENUM('Male', 'Female') NOT NULL,
        teaching_practice_location VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
""")

# Create Supervisors Table
cursor.execute("""
    CREATE TABLE IF NOT EXISTS supervisors (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        email VARCHAR(100) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        department VARCHAR(100),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
""")

# Create Coordinators Table
cursor.execute("""
    CREATE TABLE IF NOT EXISTS coordinators (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        email VARCHAR(100) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        role ENUM('Admin', 'Academic Coordinator') NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
""")

# Commit changes and close connection
db.commit()
cursor.close()
db.close()

print("Database and tables created successfully!")
